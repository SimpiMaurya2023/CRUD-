<?php include 'header.php'; ?>

	<div class="container-fluid" id="form">
		<center>
			<h4>
				<?php

					if(isset($_GET['a'])){
						if($_GET['a'] == 1){
							echo "Data Inserted Successfully!!!";
						}
					}

					if(isset($_GET['a'])){
						if($_GET['a'] == 2){
							echo "Data Updated Successfully!!!";
						}
					}

				?>		
			</h4>
		</center>
		<div class="row">
			<div class="col-sm-6" style="border: 1px solid #dcdcdc;padding: 30px 20px;border-radius: 5px;">
				<div>
					<form action="insert.php" method="POST">
						<?php
							if(isset($_GET['a'])){
								if($_GET['a'] == 3){
									echo "<h4>Name must not be Blank!!!</h4>";
								}
							}
						?>
						<input type="text" name="name" placeholder="Enter Name" class="form-control" required>
						<br>
						<?php
							if(isset($_GET['a'])){
								if($_GET['a'] == 4){
									echo "<h4>Email must not be Blank!!!</h4>";
								}
							}
						?>
						<input type="email" name="email" placeholder="Enter Email" class="form-control" required>
						<br>			
						<?php
							if(isset($_GET['a'])){
								if($_GET['a'] == 5){
									echo "<h4>Phone Number must not be Blank!!!</h4>";
								}
							}
						?>			
						<input type="number" name="no" placeholder="Enter Mobile No" class="form-control" required>
						<br>
						<?php
							if(isset($_GET['a'])){
								if($_GET['a'] == 6){
									echo "<h4>Address must not be Blank!!!</h4>";
								}
							}
						?>
						<textarea name="address" rows="10" cols="20" class="form-control" placeholder="Enter Address" required></textarea>
						<br>
						<button type="submit" class="btn btn-warning btn-md">Add</button>
					</form>
				</div>
			</div>
			<div class="col-sm-6">

				<?php  

				include 'db.php';

    			//define total number of results you want per page  
    			$results_per_page = 5;  
  
    			//find the total number of results stored in the database  
    			$query = "select *from details";  
    			$result = mysqli_query($db, $query);  
    			$number_of_result = mysqli_num_rows($result);  
  
    			//determine the total number of pages available  
    			$number_of_page = ceil ($number_of_result / $results_per_page);  
  
    			//determine which page number visitor is currently on  
    			if (!isset ($_GET['page']) ) {  
        			$page = 1;  
    			} else {  
        			$page = $_GET['page'];  
    			}  
  
    			//determine the sql LIMIT starting number for the results on the displaying page  
    			$page_first_result = ($page-1) * $results_per_page;  
  
    			//retrieve the selected results from database   
    			$query = "SELECT *FROM details LIMIT " . $page_first_result . ',' . $results_per_page;  
    			$result = mysqli_query($db, $query);  
       
  
    			//display the link of the pages in URL  
    			for($page = 1; $page<= $number_of_page; $page++) {  
        			echo '<a href = "index.php?page=' . $page . '">' . $page . ' </a>';  
    			}  
  
?>  
				
				<table class="table table-bordered table-hover">
					<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Address</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
					<?php 
						while($array = mysqli_fetch_assoc($result)){
					?>

					<tr>
						<td><?php echo $array['id']; ?></td>
						<td><?php echo $array['name']; ?></td>
						<td><?php echo $array['email']; ?></td>
						<td><?php echo $array['no']; ?></td>
						<td><?php echo $array['address']; ?></td>
						<td>
							<a href="edit.php?id=<?php echo $array['id']; ?>">
								<button type="button" class="btn btn-primary btn-sm">Edit</button>
							</a>
						</td>
						<td>
							<a href="delete.php?id=<?php echo $array['id']; ?>">
								<button type="button" class="btn btn-danger btn-sm">Delete</button>
							</a>
						</td>
					</tr>

					<?php } ?>
				</table>
			</div>
		</div>
	</div>

</body>
</html>