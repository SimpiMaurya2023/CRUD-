<?php

	include 'db.php';

	$id = $_POST['id'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['no'];
	$address = $_POST['address'];

	$sql = "UPDATE details set name='$name', email='$email', no='$phone', address='$address' WHERE id='$id'";

	// Execute query
    $result = mysqli_query($db, $sql);

    if($result){
    	header("Location: index.php?a=2");
    }else{
    	echo $db->error;
    }

?>