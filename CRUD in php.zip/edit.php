<?php include 'header.php'; ?>
<?php

	include 'db.php';

	$id = $_GET['id'];

	$sql = "SELECT * FROM details WHERE id='$id'";
	$result = mysqli_query($db,$sql);
	$array = mysqli_fetch_assoc($result)

?>
	<div class="container-fluid" id="form">
		<div class="row">
			<div class="col-sm-6" style="border: 1px solid #dcdcdc;padding: 30px 20px;border-radius: 5px;">
				<div>
					<form action="edit_insert.php" method="POST">
						<input type="text" name="name" placeholder="Enter Name" class="form-control" value="<?php echo $array['name']; ?>">
						<br>
						<input type="email" name="email" placeholder="Enter Email" class="form-control" value="<?php echo $array['email']; ?>">
						<br>						
						<input type="number" name="no" placeholder="Enter Mobile No" class="form-control" value="<?php echo $array['no']; ?>">
						<br>
						<textarea name="address" rows="10" cols="20" class="form-control" placeholder="Enter Address"><?php echo $array['address']; ?></textarea>
						<br>
						<input type="hidden" name="id" value="<?php echo $id; ?>">
						<button type="submit" class="btn btn-warning btn-md">Update</button>
					</form>
				</div>
			</div>
			<div class="col-sm-6">
				<?php
					include 'db.php';

					$sql = "SELECT * FROM details";
					$result = mysqli_query($db,$sql);
				?>
				<table class="table table-bordered table-hover">
					<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Address</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
					<?php 
						while($array = mysqli_fetch_assoc($result)){
					?>

					<tr>
						<td><?php echo $array['id']; ?></td>
						<td><?php echo $array['name']; ?></td>
						<td><?php echo $array['email']; ?></td>
						<td><?php echo $array['no']; ?></td>
						<td><?php echo $array['address']; ?></td>
						<td>
							<a href="edit.php?id=<?php echo $array['id']; ?>">
								<button type="button" class="btn btn-primary btn-sm">Edit</button>
							</a>
						</td>
						<td>
							<a href="delete.php?id=<?php echo $array['id']; ?>">
								<button type="button" class="btn btn-danger btn-sm">Delete</button>
							</a>
						</td>
					</tr>

					<?php } ?>
				</table>
			</div>
		</div>
	</div>