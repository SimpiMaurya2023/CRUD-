<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Coding Assignment</title>

	<!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Own CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <style type="text/css">
    	#top_header{
    		background-color: #000;
    		height: 05px;
    	}
    	#form{
    		margin-top: 3%;
    		margin-left: 1%;
    	}
    </style>
</head>
<body>

	<div id="top_header"></div>