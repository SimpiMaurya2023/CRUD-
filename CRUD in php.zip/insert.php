<?php

	include 'db.php';


	if($_POST['name'] == ''){
		header("Location: index.php?a=3");
	}else{
		$name = $_POST['name'];
	}

	if($_POST['email'] == ''){
		header("Location: index.php?a=4");
	}else{
		$email = $_POST['email'];
	}

	if($_POST['no'] == ''){
		header("Location: index.php?a=5");
	}else{
		$phone = $_POST['no'];
	}

	if($_POST['address'] == ''){
		header("Location: index.php?a=6");
	}else{
		$address = $_POST['address'];
	}
	

	$sql = "INSERT INTO details(name,email,no,address) VALUES('$name','$email','$phone','$address')";

	// Execute query
    $result = mysqli_query($db, $sql);

    if($result){
    	header("Location: index.php?a=1");
    }else{
    	echo $db->error;
    }

?>