<?php

	include 'db.php';

	$id = $_GET['id'];

	$sql = "DELETE FROM details WHERE id='$id'";

	// Execute query
    $result = mysqli_query($db, $sql);

    if($result){
    	header("Location: index.php?a=3");
    }else{
    	echo $db->error;
    }

?>